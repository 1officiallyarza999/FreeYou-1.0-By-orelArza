package com.freeyou

import android.app.admin.DevicePolicyManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.net.Uri
import android.provider.Settings
import com.facebook.react.bridge.*
import com.facebook.react.modules.core.DeviceEventManagerModule
import kotlin.concurrent.thread

class BlockerModule(private val ctx: ReactApplicationContext) : ReactContextBaseJavaModule(ctx) {

    override fun getName() = "FreeYouBlocker"

    private var receiver: BroadcastReceiver? = null

    init {
        BlockRepo.init(ctx)
        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) {
                if (!ctx.hasActiveReactInstance()) return
                val m = Arguments.createMap()
                m.putString("route", i?.getStringExtra("route") ?: "journal")
                m.putString("target", i?.getStringExtra("target") ?: "")
                m.putInt("count", i?.getIntExtra("count", 1) ?: 1)
                ctx.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter::class.java)
                    .emit("onBlockAttempt", m)
            }
        }
        receiver = r
        val f = IntentFilter(BlockerAccessibilityService.ACTION_BLOCKED)
        if (Build.VERSION.SDK_INT >= 33) ctx.registerReceiver(r, f, Context.RECEIVER_NOT_EXPORTED)
        else ctx.registerReceiver(r, f)
    }

    override fun invalidate() {
        receiver?.let { runCatching { ctx.unregisterReceiver(it) } }
        super.invalidate()
    }

    @ReactMethod
    fun getPendingRoute(p: Promise) {
        val pr = BlockRepo.pendingRoute()
        if (pr == null) { p.resolve(null); return }
        val m = Arguments.createMap()
        m.putString("route", pr.first); m.putString("target", pr.second); m.putInt("count", pr.third)
        p.resolve(m)
    }

    @ReactMethod
    fun clearPendingRoute() = BlockRepo.clearPendingRoute()

    private fun dpm() = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
    private fun admin() = ComponentName(ctx, AdminReceiver::class.java)

    @ReactMethod
    fun isAccessibilityEnabled(p: Promise) {
        val enabled = Settings.Secure.getString(
            ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: ""
        p.resolve(enabled.contains("${ctx.packageName}/${BlockerAccessibilityService::class.java.name}"))
    }

    @ReactMethod
    fun openAccessibilitySettings() {
        ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    @ReactMethod
    fun canDrawOverlays(p: Promise) = p.resolve(Settings.canDrawOverlays(ctx))

    @ReactMethod
    fun openOverlaySettings() {
        ctx.startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    @ReactMethod
    fun isDeviceAdmin(p: Promise) = p.resolve(dpm().isAdminActive(admin()))

    @ReactMethod
    fun requestDeviceAdmin() {
        val i = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
            .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin())
            .putExtra(
                DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                "מונע הסרה של FreeYou כשמצב קפדני פעיל. אפשר לבטל דרך מנגנון שחרור באפליקציה."
            )
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }

    @ReactMethod
    fun releaseDeviceAdmin() {
        if (!BlockRepo.strict) dpm().removeActiveAdmin(admin())
    }

    @ReactMethod
    fun syncRules(manual: ReadableArray, autoAdult: Boolean, autoScroll: Boolean, strict: Boolean) {
        val list = ArrayList<String>()
        for (i in 0 until manual.size()) manual.getString(i)?.let { list.add(it) }
        BlockRepo.save(list, autoAdult, autoScroll, strict)
    }

    @ReactMethod
    fun updateBlocklist(url: String, p: Promise) {
        thread {
            try { p.resolve(BlockRepo.updateBlocklist(url)) }
            catch (e: Exception) { p.reject("dl_failed", e) }
        }
    }

    @ReactMethod
    fun installedApps(p: Promise) {
        val pm = ctx.packageManager
        val out = Arguments.createArray()
        pm.getInstalledApplications(0)
            .filter { pm.getLaunchIntentForPackage(it.packageName) != null }
            .sortedBy { pm.getApplicationLabel(it).toString() }
            .forEach {
                val m = Arguments.createMap()
                m.putString("pkg", it.packageName)
                m.putString("label", pm.getApplicationLabel(it).toString())
                out.pushMap(m)
            }
        p.resolve(out)
    }

    @ReactMethod
    fun startAlarm(night: Boolean) {
        val i = Intent(ctx, AlarmService::class.java).putExtra("night", night)
        if (android.os.Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
    }

    @ReactMethod
    fun stopAlarm() = ctx.stopService(Intent(ctx, AlarmService::class.java))

    @ReactMethod
    fun attemptsToday(p: Promise) = p.resolve(BlockRepo.attemptsToday())

    @ReactMethod fun addListener(name: String) {}
    @ReactMethod fun removeListeners(count: Int) {}

}
