import React, {useState} from 'react';
import {View, ScrollView} from 'react-native';
import Glass from '../components/Glass';
import {Title, H2, P, Tiny, Btn, Pill} from '../components/UI';
import {useStore, daysClean} from '../store';
import {BIZ, SOCIAL} from '../data/lessons';
import {T} from '../theme';

export default function GrowScreen() {
  const {s, set} = useStore();
  const [tab, setTab] = useState<'biz' | 'soc'>('biz');
  const list = tab === 'biz' ? BIZ : SOCIAL;
  const idx = daysClean(s) % list.length;
  const l = list[idx];
  const id = tab + idx;
  const done = s.lessons.includes(id);

  return (
    <ScrollView contentContainerStyle={{paddingBottom: 130}} showsVerticalScrollIndicator={false}>
      <Title style={{marginBottom: 14}}>בנייה</Title>

      <Glass padding={5} radius={19}>
        <View style={{flexDirection: 'row-reverse', gap: 5}}>
          <Btn label="עסקים" kind={tab === 'biz' ? 'ghost' : 'ghost'} style={{flex: 1, opacity: tab === 'biz' ? 1 : 0.5}}
            onPress={() => setTab('biz')} />
          <Btn label="קשר ואומץ חברתי" kind="ghost" style={{flex: 1, opacity: tab === 'soc' ? 1 : 0.5}}
            onPress={() => setTab('soc')} />
        </View>
      </Glass>

      <Glass style={{marginTop: 12}}>
        <View style={{alignItems: 'flex-end'}}><Pill label="שיעור היום" tone="g" /></View>
        <H2 style={{marginTop: 12}}>{l.title}</H2>
        <P>{l.body}</P>
        <View style={{marginTop: 16, padding: 14, borderRadius: 18,
          backgroundColor: 'rgba(255,255,255,0.06)', borderWidth: 1, borderColor: T.edge}}>
          <P style={{color: T.txt, marginBottom: 4}}>המשימה</P>
          <P>{l.task}</P>
        </View>
        <Btn label={done ? 'הושלם היום ✓' : 'סיימתי את המשימה'} kind={done ? 'ghost' : 'warm'}
          disabled={done} style={{marginTop: 14}}
          onPress={() => set({lessons: [...s.lessons, id]})} />
      </Glass>

      <Glass style={{marginTop: 12}}>
        <H2>התקדמות</H2>
        <View style={{height: 7, borderRadius: 100, backgroundColor: 'rgba(255,255,255,0.1)', overflow: 'hidden'}}>
          <View style={{height: 7, width: `${Math.min(100, (s.lessons.length / 18) * 100)}%`, backgroundColor: T.cyan}} />
        </View>
        <Tiny style={{marginTop: 8}}>
          {s.lessons.length} שיעורים הושלמו. השיעור מתחלף כל יום — הרעיון הוא רצף, לא זלילה.
        </Tiny>
      </Glass>
    </ScrollView>
  );
}
