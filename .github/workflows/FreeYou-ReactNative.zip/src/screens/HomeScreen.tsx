import React from 'react';
import {View, Text, ScrollView, TouchableOpacity, Dimensions} from 'react-native';
import Svg, {Defs, RadialGradient, Stop, Circle} from 'react-native-svg';
import LinearGradient from 'react-native-linear-gradient';
import Glass from '../components/Glass';
import {Title, H2, P, Tiny, Row, Btn} from '../components/UI';
import {useStore, daysClean} from '../store';
import {BIZ} from '../data/lessons';
import {T, F} from '../theme';

const {width: W} = Dimensions.get('window');
const ORB = Math.min(216, W * 0.58);

/** הפנס: כדור זכוכית שמתמלא ככל שהימים עולים. הגיבור של המסך. */
function Lantern({d}: {d: number}) {
  const fill = Math.max(0.12, Math.min(1, (d % 90) / 90));
  const HALO = ORB * 1.9;
  return (
    <View style={{alignItems: 'center', paddingVertical: 26}}>
      {/* ההילה: זוהר רך שמתחזק ככל שהכדור מתמלא */}
      <View style={{position: 'absolute', top: 26 + ORB / 2 - HALO / 2, opacity: 0.35 + fill * 0.5}}>
        <Svg width={HALO} height={HALO}>
          <Defs>
            <RadialGradient id="halo" cx="50%" cy="50%" r="50%">
              <Stop offset="30%" stopColor={T.amber} stopOpacity="0.55" />
              <Stop offset="65%" stopColor={T.rose} stopOpacity="0.18" />
              <Stop offset="100%" stopColor={T.rose} stopOpacity="0" />
            </RadialGradient>
          </Defs>
          <Circle cx={HALO / 2} cy={HALO / 2} r={HALO / 2} fill="url(#halo)" />
        </Svg>
      </View>
      <View style={{width: ORB, height: ORB, borderRadius: ORB / 2, overflow: 'hidden',
        borderWidth: 1, borderColor: 'rgba(255,255,255,0.28)', justifyContent: 'flex-end'}}>
        <LinearGradient
          colors={[T.amber, T.rose]}
          style={{position: 'absolute', left: 0, right: 0, bottom: 0, height: ORB * fill, opacity: 0.6}}
        />
        <LinearGradient
          colors={['rgba(255,255,255,0.3)', 'rgba(255,255,255,0.02)']}
          style={{position: 'absolute', top: 0, left: 0, right: 0, height: ORB * 0.55}}
        />
        <View style={{position: 'absolute', top: 0, bottom: 0, left: 0, right: 0, alignItems: 'center', justifyContent: 'center'}}>
          <Text style={{fontFamily: F.display, fontSize: ORB * 0.34, color: T.txt, lineHeight: ORB * 0.36}}>{d}</Text>
          <Text style={{fontFamily: F.body, fontSize: 13, color: 'rgba(255,255,255,0.72)', marginTop: 4}}>ימים בשליטה</Text>
        </View>
      </View>
    </View>
  );
}

export default function HomeScreen({go}: {go: (r: string) => void}) {
  const {s} = useStore();
  const d = daysClean(s);
  const line =
    d === 0 ? 'היום הראשון הוא ההחלטה. כל השאר זה ביצוע.'
    : d < 7 ? 'השבוע הראשון הוא הכי רועש. הרעש נחלש, אתה לא.'
    : d < 30 ? 'הראש שלך מתחיל לחזור אליך. תשמור על זה.'
    : d < 90 ? 'אתה כבר לא נלחם בהרגל — אתה בונה זהות.'
    : 'אתה האיש שהיית רוצה שהילד שלך יראה.';

  const task = BIZ[d % BIZ.length];

  const tiles = [
    {ic: '🆘', b: 'יש לי דחף עכשיו', s: '90 שניות שמשנות הכל', r: 'sos', g: T.rose},
    {ic: '🎙️', b: 'דבר עם המנטור', s: 'קול חי, בעברית', r: 'mentor', g: T.violet},
    {ic: '📓', b: 'יומנו של גבר', s: `${s.journals.length} רשומות`, r: 'journal', g: T.cyan},
    {ic: '🛡️', b: 'החומה', s: `${s.blocked.length} חסימות ידניות`, r: 'shield', g: T.lime},
  ];

  return (
    <ScrollView contentContainerStyle={{paddingBottom: 130}} showsVerticalScrollIndicator={false}>
      <Glass padding={0}>
        <Lantern d={d} />
        <P style={{textAlign: 'center', paddingHorizontal: 24, paddingBottom: 22}}>{line}</P>
      </Glass>

      <View style={{flexDirection: 'row-reverse', flexWrap: 'wrap', gap: 11, marginTop: 12}}>
        {tiles.map(t => (
          <TouchableOpacity key={t.r} activeOpacity={0.85} onPress={() => go(t.r)} style={{width: (W - 32 - 11) / 2}}>
            <Glass radius={22} glow={t.g}>
              <Text style={{fontSize: 22, textAlign: 'right'}}>{t.ic}</Text>
              <Text style={{fontFamily: F.displayMid, fontSize: 15, color: T.txt, textAlign: 'right', marginTop: 8}}>{t.b}</Text>
              <Tiny>{t.s}</Tiny>
            </Glass>
          </TouchableOpacity>
        ))}
      </View>

      <TouchableOpacity activeOpacity={0.85} onPress={() => go('grow')}>
        <Glass style={{marginTop: 12}} glow={T.cyan}>
          <View style={{flexDirection: 'row-reverse', alignItems: 'center', gap: 14}}>
            <Text style={{fontSize: 26}}>📈</Text>
            <View style={{flex: 1}}>
              <Tiny>המשימה של היום</Tiny>
              <Text style={{fontFamily: F.displayMid, fontSize: 16, color: T.txt, textAlign: 'right', marginTop: 2}}>
                {task.title}
              </Text>
              <P style={{marginTop: 4}}>{task.task}</P>
            </View>
          </View>
        </Glass>
      </TouchableOpacity>

      <Glass style={{marginTop: 12}} glow={T.amber}>
        <H2>למה אני עושה את זה</H2>
        {s.reasons.map((r, i) => (
          <Row key={i}><P style={{flex: 1}}>◆  {r}</P></Row>
        ))}
      </Glass>

      <Glass style={{marginTop: 12}}>
        <H2>מה נבנה בינתיים</H2>
        <Row><Tiny>דחפים שרכבת עליהם</Tiny><Text style={{fontFamily: F.displayMid, color: T.txt}}>{s.urges}</Text></Row>
        <Row><Tiny>משימות גוף שהושלמו</Tiny><Text style={{fontFamily: F.displayMid, color: T.txt}}>{s.missions}</Text></Row>
        <Row><Tiny>שעות מסך שהוחזרו לך</Tiny><Text style={{fontFamily: F.displayMid, color: T.txt}}>≈ {Math.floor(d * 1.4)}</Text></Row>
        <Row><Tiny>שיעורים שסיימת</Tiny><Text style={{fontFamily: F.displayMid, color: T.txt}}>{s.lessons.length}/18</Text></Row>
      </Glass>
    </ScrollView>
  );
}
