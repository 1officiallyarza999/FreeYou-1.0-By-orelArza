import React, {useEffect, useState} from 'react';
import {View, ScrollView, TextInput, Alert} from 'react-native';
import Glass from '../components/Glass';
import {Title, H2, P, Tiny, Row, Btn, Switch} from '../components/UI';
import {useStore, DEFAULT} from '../store';
import Blocker from '../native/Blocker';
import {T, F} from '../theme';

export default function MeScreen() {
  const {s, set} = useStore();
  const [nr, setNr] = useState('');
  const [pc, setPc] = useState(s.partnerCode);
  const [admin, setAdmin] = useState(false);

  useEffect(() => {Blocker.isDeviceAdmin().then(setAdmin);}, []);

  const input = {
    backgroundColor: 'rgba(255,255,255,0.06)', borderRadius: 16, borderWidth: 1,
    borderColor: T.edge, color: T.txt, padding: 13, fontFamily: F.body, textAlign: 'right' as const,
  };

  return (
    <ScrollView contentContainerStyle={{paddingBottom: 130}} showsVerticalScrollIndicator={false}>
      <Title style={{marginBottom: 14}}>אני</Title>

      <Glass>
        <H2>הסיבות שלי</H2>
        <Tiny style={{marginBottom: 10}}>המנטור ומסכי הדחף משתמשים בדיוק במילים האלה.</Tiny>
        {s.reasons.map((r, i) => (
          <Row key={i}>
            <P style={{flex: 1}}>{r}</P>
            <Btn label="×" kind="ghost" style={{width: 46}}
              onPress={() => set({reasons: s.reasons.filter((_, j) => j !== i)})} />
          </Row>
        ))}
        <TextInput value={nr} onChangeText={setNr} placeholder="למה אתה עושה את זה?"
          placeholderTextColor="rgba(244,245,247,0.3)" style={[input, {marginTop: 12}]} />
        <Btn label="הוסף סיבה" kind="ghost" style={{marginTop: 8}}
          onPress={() => {if (nr.trim()) {set({reasons: [...s.reasons, nr.trim()]}); setNr('');}}} />
      </Glass>

      <Glass style={{marginTop: 12}}>
        <H2>הגדרות</H2>
        <Row>
          <View style={{flex: 1}}>
            <P style={{color: T.txt, fontFamily: F.bodyBold}}>מצב לילה בטוח</P>
            <Tiny>בין 23:00 ל־05:00 משימת הגוף הופכת לפרוטוקול ביתי במקום ריצה בחוץ</Tiny>
          </View>
          <Switch on={s.nightSafe} onPress={() => set({nightSafe: !s.nightSafe})} />
        </Row>
        <Row>
          <View style={{flex: 1}}>
            <P style={{color: T.txt, fontFamily: F.bodyBold}}>הגנת הסרה</P>
            <Tiny>{admin ? 'פעילה — אי אפשר למחוק את FreeYou במצב קפדני' : 'כבויה'}</Tiny>
          </View>
          <Switch on={admin} onPress={() => admin ? Blocker.releaseDeviceAdmin() : Blocker.requestDeviceAdmin()} />
        </Row>
        <View style={{marginTop: 12}}>
          <Tiny style={{marginBottom: 6}}>קוד שותף אחריות — תן אותו לחבר שאתה סומך עליו</Tiny>
          <TextInput value={pc} onChangeText={setPc} placeholder="קוד בן 6 תווים"
            placeholderTextColor="rgba(244,245,247,0.3)" style={input} />
          <Btn label="שמור קוד" kind="ghost" style={{marginTop: 8}}
            onPress={() => {set({partnerCode: pc.trim()}); Alert.alert('נשמר');}} />
        </View>
      </Glass>

      <Glass style={{marginTop: 12}}>
        <H2>היומן</H2>
        {s.journals.length === 0
          ? <Tiny>עוד לא כתבת. הרשומה הראשונה נכתבת בדרך כלל ברגע הכי קשה — וזה בדיוק הערך שלה.</Tiny>
          : s.journals.slice(-5).reverse().map((j, i) => (
            <Row key={i}>
              <View style={{flex: 1}}>
                <Tiny>{j.date}</Tiny>
                <P>{j.text.slice(0, 120)}{j.text.length > 120 ? '...' : ''}</P>
              </View>
            </Row>
          ))}
      </Glass>

      <Glass style={{marginTop: 12}}>
        <H2>נפילה קורית</H2>
        <Tiny style={{marginBottom: 12}}>
          אם נפלת — סמן בכנות. הספירה מתאפסת, הלמידה לא. תשעים אחוז מהנזק הוא מה שקורה
          ביומיים שאחרי, לא ברגע עצמו.
        </Tiny>
        <Btn label="איפוס ספירה בכנות" kind="ghost"
          onPress={() => Alert.alert('לאפס את הספירה?', 'הכנות שווה יותר מהמספר.', [
            {text: 'ביטול', style: 'cancel'},
            {text: 'אפס', onPress: () => set({start: Date.now()})},
          ])} />
      </Glass>
    </ScrollView>
  );
}
