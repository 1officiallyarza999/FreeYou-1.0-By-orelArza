import React, {useEffect, useRef, useState} from 'react';
import {View, Text, ScrollView, Alert, PermissionsAndroid, Pressable} from 'react-native';
import Geolocation from 'react-native-geolocation-service';
import Glass from '../components/Glass';
import {Title, P, Tiny, Btn, Pill} from '../components/UI';
import {useStore} from '../store';
import Blocker from '../native/Blocker';
import {T, F} from '../theme';

const isNight = () => {const h = new Date().getHours(); return h >= 23 || h < 5;};
const dist = (a: number, b: number, c: number, d: number) => {
  const R = 6371e3, r = (x: number) => (x * Math.PI) / 180;
  const dp = r(c - a), dl = r(d - b);
  const h = Math.sin(dp / 2) ** 2 + Math.cos(r(a)) * Math.cos(r(c)) * Math.sin(dl / 2) ** 2;
  return 2 * R * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h));
};

/**
 * מסך הניסיון השני. הצלצול רץ בשירות נייטיב ולכן ממשיך
 * גם אם סוגרים את האפליקציה. נפסק רק כשהאימות עובר.
 */
export default function MissionScreen({done}: {done: () => void}) {
  const {s, set} = useStore();
  const night = s.nightSafe && isNight();
  const total = night ? 12 * 60 : 20 * 60;
  const [left, setLeft] = useState(total);
  const [moved, setMoved] = useState(false);
  const [hold, setHold] = useState(0);
  const home = useRef<{la: number; lo: number} | null>(null);
  const holdT = useRef<any>(null);

  useEffect(() => {
    Blocker.startAlarm(night);
    const t = setInterval(() => setLeft(x => (x <= 1 ? 0 : x - 1)), 1000);
    return () => {clearInterval(t); clearInterval(holdT.current); Blocker.stopAlarm();};
  }, []);

  useEffect(() => {if (left === 0 || moved || hold >= 60) Blocker.stopAlarm();}, [left, moved, hold]);

  const ask = async () => {
    const ok = await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION);
    return ok === 'granted';
  };

  const markHome = async () => {
    if (!(await ask())) return Alert.alert('אין גישה למיקום', 'השתמש בכפתור ההחזקה כמוצא חירום.');
    Geolocation.getCurrentPosition(
      p => {home.current = {la: p.coords.latitude, lo: p.coords.longitude}; Alert.alert('מיקום הבית נשמר');},
      () => Alert.alert('לא הצלחתי לקרוא מיקום'),
      {enableHighAccuracy: true, timeout: 15000},
    );
  };

  const check = () => {
    if (!home.current) return;
    Geolocation.getCurrentPosition(p => {
      const d = dist(home.current!.la, home.current!.lo, p.coords.latitude, p.coords.longitude);
      if (d > 250) {setMoved(true); Alert.alert('יצאת', 'כל הכבוד. הצלצול נפסק.');}
      else Alert.alert(`עוד ${Math.max(0, 250 - Math.round(d))} מטר`);
    }, () => {}, {enableHighAccuracy: true, timeout: 15000});
  };

  const mm = String(Math.floor(left / 60)).padStart(2, '0');
  const ss = String(left % 60).padStart(2, '0');
  const unlocked = left === 0 || moved || hold >= 60;

  return (
    <ScrollView contentContainerStyle={{paddingBottom: 40}} showsVerticalScrollIndicator={false}>
      <View style={{alignItems: 'center', marginTop: 8}}>
        <Pill label="ניסיון שני היום" tone="r" />
        <Title style={{fontSize: 30, textAlign: 'center', marginTop: 14, lineHeight: 38}}>
          הדיבורים נגמרו.{'\n'}עכשיו הגוף.
        </Title>
      </View>
      <P style={{textAlign: 'center', marginTop: 10}}>
        {night
          ? 'אחרי חצות — פרוטוקול ביתי: מים קרים על הפנים, 40 שכיבות סמיכה, 40 סקוואטים, 12 דקות. אותה עוצמה, בלי ריצה בחוץ בשלוש לפנות בוקר.'
          : 'צא מהבית. ריצה, הליכה מהירה, אימון — לא משנה. הצלצול לא נפסק עד שהתרחקת 250 מטר מהבית או עד שהזמן נגמר.'}
      </P>

      <Text style={{fontFamily: F.display, fontSize: 62, color: T.txt, textAlign: 'center', marginVertical: 18}}>
        {mm}:{ss}
      </Text>

      <Glass>
        <P style={{color: T.txt, fontFamily: F.bodyBold}}>אימות יציאה</P>
        <Tiny style={{marginBottom: 12}}>
          {night ? 'סמן בסיום הפרוטוקול, או המתן לטיימר.' : 'סמן את הבית פעם אחת, ואז בדוק אחרי שיצאת.'}
        </Tiny>
        {!night && (
          <>
            <Btn label={home.current ? 'בית סומן ✓' : 'סמן את המיקום שלי כבית'} kind="ghost" onPress={markHome} />
            <Btn label="בדוק אם יצאתי" kind="warm" style={{marginTop: 8}} onPress={check} disabled={!home.current} />
          </>
        )}
        <Pressable
          onPressIn={() => {
            clearInterval(holdT.current);
            holdT.current = setInterval(
              () => setHold(h => (h >= 60 ? (clearInterval(holdT.current), 60) : h + 1)),
              1000,
            );
          }}
          onPressOut={() => {
            clearInterval(holdT.current);
            setHold(h => (h >= 60 ? 60 : 0));
          }}
          style={{marginTop: 8, paddingVertical: 15, borderRadius: 19, alignItems: 'center',
            backgroundColor: 'rgba(255,255,255,0.07)', borderWidth: 1, borderColor: T.edge}}>
          <Text style={{fontFamily: F.displayMid, fontSize: 15, color: T.txt}}>
            {hold >= 60 ? 'שוחרר' : hold > 0 ? `אל תרפה... ${60 - hold}` : 'החזק 60 שניות לביטול חירום'}
          </Text>
        </Pressable>
      </Glass>

      <Glass style={{marginTop: 12}}>
        <P style={{fontSize: 15, color: T.txt}}>"{s.reasons[0] || 'אני בוחר בגרסה הטובה שלי'}"</P>
      </Glass>

      <Btn
        label={unlocked ? 'סיימתי — השתק' : 'נעול עד שתזוז'}
        kind="hot" disabled={!unlocked} style={{marginTop: 16}}
        onPress={() => {Blocker.stopAlarm(); set({missions: s.missions + 1}); done();}} />
    </ScrollView>
  );
}
