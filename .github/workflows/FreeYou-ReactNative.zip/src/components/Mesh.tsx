import React, {useEffect, useRef} from 'react';
import {Animated, Dimensions, Easing, StyleSheet, View} from 'react-native';
import Svg, {Defs, RadialGradient, Stop, Circle} from 'react-native-svg';
import {T} from '../theme';

const {width: W, height: H} = Dimensions.get('window');

/**
 * כתמי הצבע שמתחת לזכוכית.
 *
 * ל-React Native אין filter: blur על View, אז עיגול עם opacity יוצא עם קצה חד
 * ונראה כמו כתם צבע, לא כמו זוהר. הפתרון הוא RadialGradient ב-SVG:
 * הצבע דוהה לשקוף מהמרכז החוצה, וזה הזוהר הרך שמתחת לזכוכית.
 */
function Glow({color, size, x, y, dur, dx, dy, id}: any) {
  const a = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(a, {toValue: 1, duration: dur, easing: Easing.inOut(Easing.quad), useNativeDriver: true}),
        Animated.timing(a, {toValue: 0, duration: dur, easing: Easing.inOut(Easing.quad), useNativeDriver: true}),
      ]),
    ).start();
  }, []);

  return (
    <Animated.View
      style={{
        position: 'absolute', left: x, top: y, width: size, height: size,
        transform: [
          {translateX: a.interpolate({inputRange: [0, 1], outputRange: [0, dx]})},
          {translateY: a.interpolate({inputRange: [0, 1], outputRange: [0, dy]})},
          {scale: a.interpolate({inputRange: [0, 1], outputRange: [1, 1.22]})},
        ],
      }}>
      <Svg width={size} height={size}>
        <Defs>
          <RadialGradient id={id} cx="50%" cy="50%" r="50%">
            <Stop offset="0%" stopColor={color} stopOpacity="0.62" />
            <Stop offset="45%" stopColor={color} stopOpacity="0.26" />
            <Stop offset="100%" stopColor={color} stopOpacity="0" />
          </RadialGradient>
        </Defs>
        <Circle cx={size / 2} cy={size / 2} r={size / 2} fill={`url(#${id})`} />
      </Svg>
    </Animated.View>
  );
}

export default function Mesh() {
  return (
    <View style={[StyleSheet.absoluteFill, {backgroundColor: T.ink}]} pointerEvents="none">
      <Glow id="g1" color={T.violet} size={W * 1.15} x={W * 0.2} y={-H * 0.1} dur={26000} dx={-70} dy={90} />
      <Glow id="g2" color={T.cyan} size={W * 1.0} x={-W * 0.35} y={H * 0.28} dur={31000} dx={80} dy={-60} />
      <Glow id="g3" color={T.rose} size={W * 1.0} x={W * 0.1} y={H * 0.58} dur={24000} dx={-50} dy={-70} />
      <Glow id="g4" color={T.amber} size={W * 0.7} x={W * 0.28} y={H * 0.42} dur={38000} dx={60} dy={40} />
      <View style={[StyleSheet.absoluteFill, {backgroundColor: 'rgba(5,5,7,0.34)'}]} />
    </View>
  );
}
