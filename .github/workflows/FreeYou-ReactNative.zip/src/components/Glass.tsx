import React from 'react';
import {View, StyleSheet, ViewStyle, Platform} from 'react-native';
import {BlurView} from '@react-native-community/blur';
import LinearGradient from 'react-native-linear-gradient';
import {T} from '../theme';

/**
 * שכבת הזכוכית של Liquid Glass.
 *
 * live=true  -> טשטוש אמיתי בזמן אמת. יפה, אבל יקר.
 * live=false -> שכבות צבע ששחזרו את אותו מראה בלי עלות GPU.
 *
 * באנדרואיד, BlurView בתוך רשימה נגללת גורם לקפיצות. לכן ברירת המחדל
 * לכרטיסים היא live=false, והטשטוש האמיתי שמור לדוק, לפנס ולשכבות מלאות —
 * אלמנטים סטטיים שבהם רואים את ההבדל וזה לא עולה כלום.
 */
export default function Glass({
  children, style, radius = T.r, intensity = 20, padding = 16, live = false, glow,
}: {
  children?: React.ReactNode; style?: ViewStyle; radius?: number;
  intensity?: number; padding?: number; live?: boolean; glow?: string;
}) {
  const useBlur = live && Platform.OS !== 'web';
  return (
    <View style={[styles.wrap, {borderRadius: radius}, style]}>
      {useBlur ? (
        <BlurView
          style={StyleSheet.absoluteFill}
          blurType="dark"
          blurAmount={intensity}
          overlayColor="transparent"
          reducedTransparencyFallbackColor="rgba(20,20,26,0.9)"
        />
      ) : (
        <View style={[StyleSheet.absoluteFill, {backgroundColor: 'rgba(14,14,20,0.55)'}]} />
      )}
      <LinearGradient
        colors={['rgba(255,255,255,0.14)', 'rgba(255,255,255,0.03)', 'rgba(255,255,255,0.08)']}
        start={{x: 0.15, y: 0}}
        end={{x: 0.85, y: 1}}
        style={StyleSheet.absoluteFill}
      />
      {glow && (
        <LinearGradient
          colors={[hex(glow, 0.22), 'transparent']}
          start={{x: 0.5, y: 0}} end={{x: 0.5, y: 0.9}}
          style={StyleSheet.absoluteFill}
        />
      )}
      <View style={[styles.specular, {borderRadius: radius}]} pointerEvents="none" />
      <View style={{padding}}>{children}</View>
    </View>
  );
}

/** צבע hex עם אלפא, כדי שהגבול והזוהר יהיו באותו גוון */
function hex(c: string, a: number) {
  const n = c.replace('#', '');
  const r = parseInt(n.slice(0, 2), 16), g = parseInt(n.slice(2, 4), 16), b = parseInt(n.slice(4, 6), 16);
  return `rgba(${r},${g},${b},${a})`;
}

const styles = StyleSheet.create({
  wrap: {overflow: 'hidden', borderWidth: 1, borderColor: T.edge},
  specular: {...StyleSheet.absoluteFillObject, borderTopWidth: 1.2, borderTopColor: 'rgba(255,255,255,0.34)'},
});
