export type Msg = {role: 'user' | 'assistant'; content: string};

/**
 * חשוב: אל תשים מפתח API בתוך האפליקציה — כל אחד יכול לחלץ אותו מה-APK.
 * הרם פונקציה קטנה (Cloudflare Workers / Vercel) שמעבירה את הבקשה עם המפתח שלך.
 * הקוד של הפרוקסי נמצא ב-README.
 */
const PROXY = 'https://your-worker.workers.dev/mentor';

const systemPrompt = (reasons: string[], days: number) => `אתה מנטור גברי בעברית באפליקציה FreeYou, לגבר שנגמל מפורנוגרפיה ומגלילה כפייתית.
קול: חם, יציב, אח גדול. לא מטיף, לא שופט, לא מתייפייף.
חובה: תשובות קצרות — 2 עד 4 משפטים, שנשמעות טוב כשמקריאים אותן בקול רם.
עקרונות: בושה מגבירה נפילות — תמיד תפריד בין המעשה לבין האדם. תלמד אותו לרכוב על הדחף (הוא מגיע בגל ודועך תוך 15-20 דקות). תחזיר אותו לגוף ולפעולה קונקרטית עכשיו. תזכיר לו את הסיבות שלו במילים שלו.
הסיבות שלו: ${reasons.join(' | ')}. ימים נקיים: ${days}.
אם הוא מדבר על פגיעה עצמית או משבר אמיתי — תגיד לו בעדינות לפנות לעזרה אנושית (ער"ן 1201).
תמיד סיים בשאלה אחת קצרה או בפעולה אחת שהוא עושה בדקה הקרובה.`;

export async function askMentor(chat: Msg[], reasons: string[], days: number): Promise<string> {
  try {
    const r = await fetch(PROXY, {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        model: 'claude-sonnet-4-6',
        max_tokens: 400,
        system: systemPrompt(reasons, days),
        messages: chat.slice(-12),
      }),
    });
    const d = await r.json();
    return (d.content || []).filter((c: any) => c.type === 'text').map((c: any) => c.text).join(' ').trim()
      || 'אני כאן. תנסה שוב.';
  } catch {
    return 'אין לי חיבור כרגע. עד שיחזור — קום, שתה מים קרים, וצא לחמש דקות אוויר. זה לא פחות ממה שהייתי אומר לך.';
  }
}
