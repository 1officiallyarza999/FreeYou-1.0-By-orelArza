import {Platform} from 'react-native';

export const T = {
  ink: '#050507',
  violet: '#7C3AED',
  cyan: '#22D3EE',
  rose: '#FB2E6B',
  amber: '#FFB020',
  lime: '#A3E635',
  txt: '#F4F5F7',
  dim: 'rgba(244,245,247,0.56)',
  dimmer: 'rgba(244,245,247,0.34)',
  edge: 'rgba(255,255,255,0.16)',
  r: 26,
};

/**
 * האפליקציה רצה מיד עם גופן המערכת.
 * כשתניח את Rubik ו-Assistant ב-android/app/src/main/assets/fonts,
 * הפוך את הדגל ל-true והטיפוגרפיה תתחלף. ראה README.
 */
export const CUSTOM_FONTS = false;

const sys = Platform.select({android: 'sans-serif', default: 'System'})!;
const sysMedium = Platform.select({android: 'sans-serif-medium', default: 'System'})!;

export const F = CUSTOM_FONTS
  ? {display: 'Rubik-Black', displayMid: 'Rubik-Bold', body: 'Assistant-Regular', bodyBold: 'Assistant-SemiBold'}
  : {display: sysMedium, displayMid: sysMedium, body: sys, bodyBold: sysMedium};

// כשאין גופן מותאם, המשקל מגיע מ-fontWeight במקום משם המשפחה
export const W = CUSTOM_FONTS
  ? {display: undefined, mid: undefined}
  : {display: '800' as const, mid: '700' as const};
