import React, {createContext, useContext, useEffect, useState} from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Blocker from './native/Blocker';

export type State = {
  start: number;
  urges: number;
  missions: number;
  journals: {date: string; text: string}[];
  reasons: string[];
  blocked: string[];
  autoAdult: boolean;
  autoScroll: boolean;
  strict: boolean;
  nightSafe: boolean;
  partnerCode: string;
  lessons: string[];
  attempts: Record<string, number>;
};

export const DEFAULT: State = {
  start: Date.now(),
  urges: 0,
  missions: 0,
  journals: [],
  reasons: [
    'המשפחה שלי ראויה לגבר נוכח, לא לגבר שנעלם למסך',
    'אני רוצה לבנות עסק שדורש את הראש שלי צלול',
    'אני לא רוצה להיות אדם שמסתיר דברים',
  ],
  blocked: [],
  autoAdult: true,
  autoScroll: false,
  strict: false,
  nightSafe: true,
  partnerCode: '',
  lessons: [],
  attempts: {},
};

const KEY = 'freeyou:state:v1';

const Ctx = createContext<{
  s: State;
  set: (patch: Partial<State>) => void;
  ready: boolean;
}>({s: DEFAULT, set: () => {}, ready: false});

export const useStore = () => useContext(Ctx);

export function StoreProvider({children}: {children: React.ReactNode}) {
  const [s, setS] = useState<State>(DEFAULT);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    AsyncStorage.getItem(KEY).then(raw => {
      if (raw) {
        try {
          setS({...DEFAULT, ...JSON.parse(raw)});
        } catch {}
      }
      setReady(true);
    });
  }, []);

  // כל שינוי במצב מסונכרן גם לשירות הנייטיב, שהוא זה שחוסם בפועל
  useEffect(() => {
    if (!ready) return;
    AsyncStorage.setItem(KEY, JSON.stringify(s));
    Blocker.syncRules({
      manual: s.blocked,
      autoAdult: s.autoAdult,
      autoScroll: s.autoScroll,
      strict: s.strict,
    });
  }, [s, ready]);

  const set = (patch: Partial<State>) => setS(prev => ({...prev, ...patch}));
  return React.createElement(Ctx.Provider, {value: {s, set, ready}}, children);
}

export const daysClean = (s: State) => Math.floor((Date.now() - s.start) / 864e5);
export const todayKey = () => new Date().toISOString().slice(0, 10);
export const attemptsToday = (s: State) => s.attempts[todayKey()] || 0;
